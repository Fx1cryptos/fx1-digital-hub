import ConfettiBlast from "@/components/ConfettiBlast";
import { useMembership } from "@/hooks/useMembership";
// ...
const { isMember } = useMembership();
// ...
return (
  <div className="mt-12 relative">
    <ConfettiBlast active={isMember} />
    {/* ...rest of leaderboard */}
  </div>
);