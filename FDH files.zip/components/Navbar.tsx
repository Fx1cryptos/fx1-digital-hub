<li>
  <a href="/passport" className="hover:text-accent transition">
    🎟️ Access Pass
  </a>
</li>