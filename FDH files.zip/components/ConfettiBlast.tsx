"use client";
import Confetti from "react-confetti";
import { useEffect, useState } from "react";

export default function ConfettiBlast({ active = false }) {
  const [show, setShow] = useState(active);

  useEffect(() => {
    if (active) {
      setShow(true);
      const timer = setTimeout(() => setShow(false), 3500);
      return () => clearTimeout(timer);
    }
  }, [active]);

  if (!show) return null;
  // Optional: use window size hooks in production
  return <Confetti width={window.innerWidth} height={window.innerHeight} />;
}