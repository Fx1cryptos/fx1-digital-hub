import { useMembership } from "@/hooks/useMembership";
// ...
const { badge } = useMembership();
return (
  // ...other profile info
  {badge ? (
    <span className="inline-block px-4 py-2 bg-accent text-white rounded-full text-sm font-bold">
      {badge}
    </span>
  ) : (
    <p>No badge yet. <a href="/passport">Mint your access pass</a>.</p>
  )}
);