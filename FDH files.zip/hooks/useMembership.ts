"use client";

import { useAccount, useReadContract } from "wagmi";

const passportAddress = "0x58549eda490af30fe65b8c0a609da70c4e962f59";
const eliteAddress = "0xc4b8dfdc40fdc597ecd5a413c89fb341b017185f";

const erc721ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "owner", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  }
];

export function useMembership() {
  const { address } = useAccount();

  const { data: passportBalance } = useReadContract({
    address: passportAddress as `0x${string}`,
    abi: erc721ABI,
    functionName: "balanceOf",
    args: [address as `0x${string}`],
    chainId: 8453,
  });

  const { data: eliteBalance } = useReadContract({
    address: eliteAddress as `0x${string}`,
    abi: erc721ABI,
    functionName: "balanceOf",
    args: [address as `0x${string}`],
    chainId: 8453,
  });

  const hasPassport = passportBalance && Number(passportBalance) > 0;
  const hasElite = eliteBalance && Number(eliteBalance) > 0;

  let badge: string | null = null;
  let role: "elite" | "citizen" | null = null;
  if (hasElite) {
    badge = "🌟 Elite Creator";
    role = "elite";
  } else if (hasPassport) {
    badge = "🪪 Citizen";
    role = "citizen";
  }

  return { isMember: hasPassport || hasElite, badge, role, hasPassport, hasElite };
}