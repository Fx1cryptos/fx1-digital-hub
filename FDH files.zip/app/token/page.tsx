import { useMembership } from "@/hooks/useMembership";
const { badge, role } = useMembership();
return (
  <div>
    {/* ...token stats */}
    {badge && (
      <div className={`mt-4 px-4 py-2 rounded-full font-bold text-lg ${
        role === "elite" ? "bg-yellow-400 text-black animate-pulse" : "bg-gray-900 text-accent"
      }`}>
        {badge} {role === "elite" ? "→ Boosted Rewards!" : "→ Base Rewards"}
      </div>
    )}
    {/* ...rest of page */}
  </div>
);