import ConfettiBlast from "@/components/ConfettiBlast";
import { useMembership } from "@/hooks/useMembership";
// ...
const { isMember, badge, role } = useMembership();
// ...
return isMember ? (
  <div className="container mx-auto py-20 relative">
    <ConfettiBlast active={true} />
    <h1 className="text-5xl font-bold mb-6">🎨 Creator Hub</h1>
    {role === "elite" && (
      <span className="inline-block px-4 py-2 bg-yellow-500 text-black rounded-full text-lg font-bold animate-pulse mb-4 ml-2">
        🌟 Elite Creator
      </span>
    )}
    {/* ...rest of creator UI */}
  </div>
) : (
  // ...locked UI as before
);